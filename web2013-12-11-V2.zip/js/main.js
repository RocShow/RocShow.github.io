$(document).ready(function(){
    var $recruit = $('.recruit'),
        $aboutUs = $('.aboutUs'),
        $contactUs = $('.contactUs'),
        $details = $('#details'),
        $mask = $('.mask'),
        $triangle = $('.recruit #positions .triangle'),
        $pic = $('#pics');
    var tirangleLocations = ["0px","256px","512px","768px"];
    var firstTime = true;

    /*设置菜单点击事件*/
    $('#banner .menu-item#recruit').on('click',function(){
        $aboutUs.hide();
        $recruit.show(0,function(){
            $("body,html").animate({scrollTop:$recruit.offset().top - 50},300);
        });
    });
    $('#banner .menu-item#about').on('click',function(){
        $recruit.hide();
        $aboutUs.show(0,function(){
            $("body,html").animate({scrollTop:$aboutUs.offset().top - 100},300);
        });
    });
    $('#banner .menu-item#contact').on('click',function(){
        $mask.show();
        $contactUs.show();
    });
    $('.contactUs #close').on('click',function(){
        $mask.hide();
        $contactUs.hide();
    });

    /* 设置职位点击事件 */
    $('.recruit #positions #jobs .position .description .view').on('click',function(e){
        if(firstTime){
            $('.recruit #positions').css("padding-bottom","0px");
            $triangle.show();
            $details.show();
            firstTime = false;
        }
        switch(e.target.id){
            case "engineer":
                $triangle.css("left",tirangleLocations[0]);
                renderPositions(positions['engineer']);
                break;
            case "designer":
                $triangle.css("left",tirangleLocations[1]);
                renderPositions(positions['designer']);
                break;
            case "operator":
                $triangle.css("left",tirangleLocations[2]);
                renderPositions(positions['operator']);
                break;
            case "administrator":
                $triangle.css("left",tirangleLocations[3]);
                renderPositions(positions['administrator']);
                break;
        }
    });

    renderPositions(positions['engineer']);

    /* 设置六边形点击事件 */
    $('.hexagon').on('click',function(e){
        var scroll_offset = $('#pics').offset();  
        $('body,html').animate({scrollTop:scroll_offset.top},500);
    });

    var visible = {
        wage:$pic.find("#wages").offset().top,
        enter:$pic.find("#entertainment").offset().top,
        activity:$pic.find("#activity").offset().top,
        meeting:$pic.find("#meeting").offset().top,
        chair:$pic.find("#chair").offset().top,
        more:$pic.find("#more").offset().top
    }
    /* 设置滚动条事件 */
    $(window.document).on('scroll',function(){
        setTimeout(function(){
            var scrollTop = $(document).scrollTop() + $(window).height() + 10;
            if(visible.wage && scrollTop >= visible.wage){
                //$pic.find("#wages").animate({border:"0px",width:"398px",height:"631px"},700);
                $pic.find("#wages img").animate({opacity:"1"},700);
                //$pic.find("#mac").animate({border:"0px",width:"582px",height:"291px"},700);
                $pic.find("#mac img").animate({opacity:"1"},700);
                visible.wage = null;
            }
            if(visible.enter && scrollTop >= visible.enter){
                //$pic.find("#entertainment").animate({border:"0px",width:"582px",height:"340px"},700);
                $pic.find("#entertainment img").animate({opacity:"1"},700);
            }
            if(visible.activity && scrollTop >= visible.activity){
                //$pic.find("#activity").animate({border:"0px",width:"980px",height:"449px"},700);
                $pic.find("#activity img").animate({opacity:"1"},700);
            }
            if(visible.meeting && scrollTop >= visible.meeting){
                //$pic.find("#meeting").animate({border:"0px",width:"512px",height:"311px"},700);
                $pic.find("#meeting img").animate({opacity:"1"},700);
                //$pic.find("#snack").animate({border:"0px",width:"468px",height:"417px"},700);
                $pic.find("#snack img").animate({opacity:"1"},700);
            }
            if(visible.chair && scrollTop >= visible.chair){
                //$pic.find("#chair").animate({border:"0px",width:"512px",height:"419px"},700);
                $pic.find("#chair img").animate({opacity:"1"},700);
            }
            if(visible.more && scrollTop >= visible.more){
                //$pic.find("#more").animate({border:"0px",width:"468px",height:"313px"},700);
                $pic.find("#more img").animate({opacity:"1"},700);
            }
        },0);
    });
    /* 
     * 渲染职位详情 
     * 职位介绍请编辑data.js 
     */
    function renderPositions(data){
        if(!data){
            return false;
        }
        if(data.profession){
            $details.find('.title').html(data.profession);
        }
        if(data.menu && data.menu instanceof Array){
            $details.find('.positions').html("");
            $.each(data.menu,function(index,val){
                var $newPosition = $('<div class="position">' + val.tag +'</div>');
                $newPosition.on('click',function(e){
                    var p = $details.find('.position');
                    p.removeClass("active");
                    $(e.target).addClass("active");
                    $details.find('.details .name').html(val.name);
                    $details.find('.details .item-description.duty').html(val.duty.join('<br/>'));
                    if(val.priority){
                        $details.find('.details .item-description.priority').html(val.priority.join('<br/>'));
                        $('.recruit #details .details .priority').show();
                    }else{
                        $('.recruit #details .details .priority').hide();
                    }
                    $details.find('.details .item-description.qulification').html(val.qulification.join('<br/>'));
                    $details.find('.details .apply a').attr("href",val.url);
                });
                $details.find('.positions').append($newPosition);
            });
            $details.find('.position:first-child').trigger('click');
            /*滚动*/
            var scroll_offset = $details.offset();  
            $("body,html").animate({scrollTop:scroll_offset.top - 327},300);
        }
    }
});